<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= html_escape($title); ?></title>
    <link rel="stylesheet" href="<?= base_url('assets/css/app.css?v=20260524j'); ?>">
</head>
<body class="login-body">
    <section class="login-card admin-login-card">
        <div class="login-mark">SN</div>
        <p class="eyebrow">Administrator</p>
        <h1>Sahabat Nara</h1>
        <p>Masuk untuk mengelola pendaftaran, data training, foto trainer, logo mitra, dan flyer program.</p>
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert error"><?= html_escape($this->session->flashdata('error')); ?></div>
        <?php endif; ?>
        <form class="form" method="post" action="<?= site_url('auth/login'); ?>">
            <label>Email<input type="email" name="email" required></label>
            <label>Password<input type="password" name="password" required></label>
            <button class="btn primary" type="submit">Masuk</button>
        </form>
        <p class="hint">Akun admin dibuat melalui perintah instalasi <code>tools/create_admin.php</code>.</p>
    </section>
</body>
</html>
