<section class="page-hero article-hero">
    <p class="eyebrow">Artikel & Insights</p>
    <h1>Insight HR, leadership, dan dunia kerja Indonesia</h1>
    <p>Artikel terhubung dengan ProleadIndonesia.com sebagai media partner.</p>
</section>

<section class="section article-list-section">
    <div class="grid cards">
        <?php foreach ($articles as $article): ?>
            <article class="card">
                <h3><?= html_escape($article['title']); ?></h3>
                <p><?= html_escape($article['summary']); ?></p>
                <a href="<?= html_escape($article['external_url']); ?>" target="_blank" rel="noopener">Baca di ProleadIndonesia</a>
            </article>
        <?php endforeach; ?>
    </div>
</section>
