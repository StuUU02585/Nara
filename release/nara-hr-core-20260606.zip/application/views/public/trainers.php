<section class="page-hero trainer-hero">
    <p class="eyebrow">Trainer & Konsultan</p>
    <h1>Praktisi HR senior dengan pengalaman nasional dan multinasional</h1>
</section>

<section class="section trainer-list-section">
    <div class="grid cards">
        <?php foreach ($trainers as $trainer): ?>
            <article class="card">
                <?php if ($trainer['photo_path']): ?>
                    <img class="trainer-photo large" src="<?= base_url($trainer['photo_path']); ?>" alt="<?= html_escape($trainer['name']); ?>" loading="lazy" decoding="async">
                <?php endif; ?>
                <h3><?= html_escape($trainer['name']); ?></h3>
                <p><strong><?= html_escape($trainer['role']); ?></strong></p>
                <p><?= html_escape($trainer['expertise']); ?></p>
                <p><?= html_escape($trainer['bio']); ?></p>
            </article>
        <?php endforeach; ?>
    </div>
</section>
