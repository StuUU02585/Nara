<section class="page-hero short-training-hero">
    <p class="eyebrow">Short Training</p>
    <h1>Pelatihan singkat intensif, praktis, dan langsung diterapkan</h1>
    <p>Pelatihan singkat intensif dengan materi padat, praktis, dan langsung bisa diterapkan. Cocok untuk Anda yang ingin upgrade skill cepat tanpa meninggalkan pekerjaan.</p>
</section>

<section class="section short-benefits">
    <h2>Manfaat</h2>
    <div class="short-benefit-grid">
        <article><span>01</span><p>Jadwal fleksibel secara online maupun offline</p></article>
        <article><span>02</span><p>Materi terkini yang menyesuaikan regulasi</p></article>
        <article><span>03</span><p>Sertifikat keikutsertaan program pelatihan</p></article>
        <article><span>04</span><p>Akses ke komunitas alumni Nara-HR</p></article>
    </div>
</section>

<section class="section muted short-agenda">
    <h2>Agenda Pelatihan</h2>
    <p class="agenda-month-note">Menampilkan agenda bulan berjalan dan bulan berikutnya: <strong><?= html_escape($active_month_label ?? date('F Y')); ?></strong></p>
    <div class="table-wrap flowbite-table">
        <table>
            <thead>
                <tr>
                    <th>Agenda</th>
                    <th>Program</th>
                    <th>Tanggal</th>
                    <th>Mode</th>
                    <th>Flyer</th>
                    <th>Konsultasi CS Nara-HR</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($trainings as $training): ?>
                    <?php
                        $program_name = $training['title'] ?: $training['program_title'];
                        $program_message = urlencode('Saya ingin menanyakan program ' . $program_name);
                    ?>
                    <tr>
                        <td><?= html_escape($training['title']); ?></td>
                        <td><?= html_escape($training['program_title']); ?></td>
                        <td><?= html_escape($training['schedule_label']); ?></td>
                        <td><?= html_escape($training['venue_method']); ?></td>
                        <td>
                            <?php if ($training['flyer_path']): ?>
                                <a href="<?= base_url($training['flyer_path']); ?>" target="_blank" rel="noopener">Lihat flyer</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <a class="table-action-link" href="https://wa.me/<?= preg_replace('/\D+/', '', $site['whatsapp']); ?>?text=<?= $program_message; ?>" target="_blank" rel="noopener">Konsultasi CS Nara-HR</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($trainings)): ?>
                    <tr>
                        <td colspan="6">Belum ada agenda pelatihan untuk periode <?= html_escape($active_month_label ?? date('F Y')); ?>.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
